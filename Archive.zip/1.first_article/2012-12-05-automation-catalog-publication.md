--- 
layout: post
title: Welcome Mr. Young Gil Kim
subtitle: Things are changing very fast.
author: Min Soo Kim
published: false
demote: 4
---



# Product Line is editted


This is a guide to automate catalog publishing. Basically, a how to guide to organizing your catalog data in certain way, so that the layout process can be automated. This is a guide to automate catalog publishing. Basically, a how to guide to organizing your catalog data in certain way, so that the layout process can be automated.

This is a guide to automate catalog publishing. Basically, a how to guide to organizing your catalog data in certain way, so that the layout process can be automated. This is a guide to automate catalog publishing. Basically, a how to guide to organizing your catalog data in certain way, so that the layout process can be automated.
	 
# Terms Used
Section, Category, Product Info, Package Option will be used. So let's clarify what they mean. Section, Category, Product Info, Package Option will be used. Like Electronic, Food, Clothing, and so on Like Electronic, Food, Clothing, and so on Like Electronic, Food, Clothing, and so on
So let's clarify what they mean.
	
## Section
Section means top level partition of the catalog, a big division 
Like Electronic, Food, Clothing, and so on
A Section can contains several categories
Section means top level partition of the catalog, a big division 
Like Electronic, Food, Clothing, and so on
A Section can contains several categories Section means top level partition of the catalog, a big division 
Like Electronic, Food, Clothing, and so on
A Section can contains several categories
	
## Category
A Category is a sub division of the section
For example: in Electronics section TV, Computer, Phone would be examples of category.
A Category is a sub division of the section
For example: in Electronics section TV, Computer, Phone would be examples of category.
A Category is a sub division of the section
For example: in Electronics section TV, Computer, Phone would be examples of category.

## Product Information

Finally product information. Typically it will have
name, category_code, product_code, price, description, picture, brand, country of origin, delivery method, delivery cost, product condition, 

## Package Options

Package options are sub category of product info, depending on product packaging. It is a variation for shipping and packaging. For example, one for 1,2 or 6 in the package, every thing is same except packing quantity


# How does it work?

Finally product information. Typically it will have
name, category_code, product_code, price, description, picture, brand, country of origin, delivery method, delivery cost, product condition, Finally product information. Typically it will have name, category_code, product_code, price, description, picture, brand, country of origin, delivery method, delivery cost, product condition, 

## Organizing data

It is critical to organize the data. Once the data is well prepared, rest can be automated, but it should be well prepared. We use Excel Spreadsheet to manage the data to start with. We can the data between the publisher and the automation server using several methods, but one of the easiest method is to use Google Drive. You can upload your Excel Spreadsheet data to Google Drive, then the data can be shared with the automation tool chain.
	
# data sheet and section info sheet
We need two Excel Worksheet, one for rows of data, and one for section information. We are use two separate worksheet to avoid the complication.
For Example
1. Create Excel worksheet files 

2. Create Goole Drive account and download GoogleDrive App and install in on your DeskTop		

3. Upload data to Google Drive

4. Send Job request to the Catalog Automation Service with you GoogleDrive login info and worksheet url 

5. The service will
	1. Pull the data from the Google worksheet.
	2. Generate a PDF version of the catalog 
	3. Put the result back to your GoogleDrive with .pdf extension
 	4. You should be able to find PDF version of the catalog in your GoogleDive within 1 min.

# Test Drive the Service
 
Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet.

Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet.

## How do I create Excel worksheet

Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet.

# How do I upload the Excel worksheet to GoogleDrive

Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet.

# How do I request service

Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet.

Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. This is a guide to automate catalog publishing. Basically, a how to guide to organizing your catalog data in certain way, so that the layout process can be automated. This is a guide to automate catalog publishing. Basically, a how to guide to organizing your catalog data in certain way, so that the layout process can be automated.

This is a guide to automate catalog publishing. Basically, a how to guide to organizing your catalog data in certain way, so that the layout process can be automated. This is a guide to automate catalog publishing. Basically, a how to guide to organizing your catalog data in certain way, so that the layout process can be automated.

# You request service by calling

Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet.

Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. Pull the data from the Google worksheet. This is a guide to automate catalog publishing. Basically, a how to guide to organizing your catalog data in certain way, so that the layout process can be automated. This is a guide to automate catalog publishing. Basically, a how to guide to organizing your catalog data in certain way, so that the layout process can be automated.

