--- 
layout: post
title: Making rlayout for variable publishing
subtitle: Things are changing very fast.
author: Min Soo Kim

date: 2012-12-18 09:26
comments: true
categories: 
---


# One I want to make RLayout to handle the user inputing from non-RLayout files.

User should be able to to edit the content of a designated file such as CSV or markdown files and the layout should pickup the change and get automatically updated with changed content. We can use this feature with the data file residing in Google Drive or DropBox. User doesn\'t need to learn to use the page layout app or how to design.In order to edit content, user has to open the rlayout document, but I want to make it so that user doesn't need not open the document. 

# Some running head goes here.

User should be able to to edit the content of a designated file such as CSV or markdown files and the layout should pickup the change and get automatically updated with changed content. We can use this feature with the data file residing in Google Drive or DropBox. User doesn\'t need to learn to use the page layout app or how to design.In order to edit content, user has to open the rlayout document, but I want to make it so that user doesn't need not open the document. 

# One I want to make RLayout to handle the user inputing from non-RLayout files.

User should be able to to edit the content of a designated file such as CSV or markdown files and the layout should pickup the change and get automatically updated with changed content. We can use this feature with the data file residing in Google Drive or DropBox. User doesn\'t need to learn to use the page layout app or how to design.In order to edit content, user has to open the rlayout document, but I want to make it so that user doesn't need not open the document. 

# Some running head goes here.

User should be able to to edit the content of a designated file such as CSV or markdown files and the layout should pickup the change and get automatically updated with changed content. We can use this feature with the data file residing in Google Drive or DropBox. User doesn\'t need to learn to use the page layout app or how to design.In order to edit content, user has to open the rlayout document, but I want to make it so that user doesn't need not open the document. 

# One I want to make RLayout to handle the user inputing from non-RLayout files.

User should be able to to edit the content of a designated file such as CSV or markdown files and the layout should pickup the change and get automatically updated with changed content. We can use this feature with the data file residing in Google Drive or DropBox. User doesn\'t need to learn to use the page layout app or how to design.In order to edit content, user has to open the rlayout document, but I want to make it so that user doesn't need not open the document. 

# Some running head goes here.

User should be able to to edit the content of a designated file such as CSV or markdown files and the layout should pickup the change and get automatically updated with changed content. We can use this feature with the data file residing in Google Drive or DropBox. User doesn\'t need to learn to use the page layout app or how to design.In order to edit content, user has to open the rlayout document, but I want to make it so that user doesn't need not open the document. 

# One I want to make RLayout to handle the user inputing from non-RLayout files.

User should be able to to edit the content of a designated file such as CSV or markdown files and the layout should pickup the change and get automatically updated with changed content. We can use this feature with the data file residing in Google Drive or DropBox. User doesn\'t need to learn to use the page layout app or how to design.In order to edit content, user has to open the rlayout document, but I want to make it so that user doesn't need not open the document. 

# Some running head goes here.

User should be able to to edit the content of a designated file such as CSV or markdown files and the layout should pickup the change and get automatically updated with changed content. We can use this feature with the data file residing in Google Drive or DropBox. User doesn\'t need to learn to use the page layout app or how to design.In order to edit content, user has to open the rlayout document, but I want to make it so that user doesn't need not open the document. 

